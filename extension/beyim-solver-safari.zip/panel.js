"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/panel/beta.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill(), 1);

  // src/shared/beta-config.ts
  var betaApi = true ? "https://api.groq.com" : "";
  var safari = true;
  var directGroq = true;

  // src/shared/errors.ts
  var SolverError = class extends Error {
    name = "SolverError";
  };
  var Cancelled = class extends SolverError {
    name = "Cancelled";
  };
  var AnswerFormatError = class extends SolverError {
    name = "AnswerFormatError";
  };
  var ApiError = class extends SolverError {
    name = "ApiError";
    status;
    constructor(status2, message) {
      super(message);
      this.status = status2;
    }
  };
  function checkpoint(signal) {
    if (signal?.aborted) {
      throw new Cancelled("\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E. \u041D\u043E\u0432\u044B\u0435 \u043E\u0442\u0432\u0435\u0442\u044B \u043D\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u044E\u0442\u0441\u044F.");
    }
  }
  function sleep(ms, signal) {
    if (signal?.aborted) {
      return Promise.reject(new Cancelled("\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E. \u041D\u043E\u0432\u044B\u0435 \u043E\u0442\u0432\u0435\u0442\u044B \u043D\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u044E\u0442\u0441\u044F."));
    }
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        signal?.removeEventListener("abort", onAbort);
        resolve();
      }, Math.max(0, ms));
      const onAbort = () => {
        clearTimeout(timer);
        reject(new Cancelled("\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E. \u041D\u043E\u0432\u044B\u0435 \u043E\u0442\u0432\u0435\u0442\u044B \u043D\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u044E\u0442\u0441\u044F."));
      };
      signal?.addEventListener("abort", onAbort, { once: true });
    });
  }

  // src/shared/question.ts
  var ANSWER_SCHEMA = {
    type: "object",
    properties: {
      answer_ids: { type: "array", items: { type: "integer" } },
      text_answer: { type: "string" },
      explanation: { type: "string" },
      confidence: { type: "number" },
      needs_help: { type: "boolean" }
    },
    required: ["answer_ids", "text_answer", "explanation", "confidence", "needs_help"],
    additionalProperties: false
  };
  function answerSchema(question) {
    const schema = JSON.parse(JSON.stringify(ANSWER_SCHEMA));
    const properties = schema.properties;
    const explanation = properties.explanation;
    schema.properties = { explanation, ...properties };
    const ids = properties.answer_ids;
    if (question.kind === "text") {
      ids.minItems = 0;
      ids.maxItems = 0;
      properties.text_answer.minLength = 1;
    } else if (question.options.length > 0) {
      ids.items.enum = Array.from({ length: question.options.length }, (_, index) => index + 1);
      ids.minItems = 1;
      ids.maxItems = question.kind === "single" ? 1 : question.options.length;
      ids.uniqueItems = true;
      properties.text_answer.enum = [""];
    } else {
      throw new SolverError("\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0439 \u0442\u0438\u043F \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u0438\u043B\u0438 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u044E\u0442 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u044B.");
    }
    properties.confidence.minimum = 0;
    properties.confidence.maximum = 1;
    return schema;
  }
  function validateAnswer(value, question, threshold2) {
    if (typeof value !== "object" || value === null || Array.isArray(value)) {
      throw new AnswerFormatError("\u041C\u043E\u0434\u0435\u043B\u044C \u0432\u0435\u0440\u043D\u0443\u043B\u0430 \u043D\u0435\u0432\u0435\u0440\u043D\u0443\u044E \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0443 \u043E\u0442\u0432\u0435\u0442\u0430.");
    }
    const answer = value;
    const required = ANSWER_SCHEMA.required;
    if (Object.keys(answer).length !== required.length || required.some((key) => !(key in answer))) {
      throw new AnswerFormatError("\u041C\u043E\u0434\u0435\u043B\u044C \u0432\u0435\u0440\u043D\u0443\u043B\u0430 \u043D\u0435\u0432\u0435\u0440\u043D\u0443\u044E \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0443 \u043E\u0442\u0432\u0435\u0442\u0430.");
    }
    const confidence = answer.confidence;
    if (typeof confidence !== "number" || !Number.isFinite(confidence) || confidence < 0 || confidence > 1) {
      throw new AnswerFormatError("\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0443\u0432\u0435\u0440\u0435\u043D\u043D\u043E\u0441\u0442\u044C \u043C\u043E\u0434\u0435\u043B\u0438.");
    }
    if (typeof answer.needs_help !== "boolean" || typeof answer.explanation !== "string") {
      throw new AnswerFormatError("\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0435 \u043F\u043E\u043B\u044F \u043E\u0442\u0432\u0435\u0442\u0430 \u043C\u043E\u0434\u0435\u043B\u0438.");
    }
    if (answer.needs_help || confidence < threshold2) {
      throw new SolverError(`\u041C\u043E\u0434\u0435\u043B\u044C \u043D\u0435 \u0443\u0432\u0435\u0440\u0435\u043D\u0430 (${Math.round(confidence * 100)}%). ${answer.explanation}`);
    }
    const ids = answer.answer_ids;
    if (!Array.isArray(ids) || ids.some((id) => !Number.isInteger(id))) {
      throw new AnswerFormatError("\u041C\u043E\u0434\u0435\u043B\u044C \u0432\u0435\u0440\u043D\u0443\u043B\u0430 \u043D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0435 \u043D\u043E\u043C\u0435\u0440\u0430 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u043E\u0432.");
    }
    if (new Set(ids).size !== ids.length || ids.some((id) => id < 1 || id > question.options.length)) {
      throw new AnswerFormatError("\u041D\u043E\u043C\u0435\u0440 \u043E\u0442\u0432\u0435\u0442\u0430 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0432 \u0437\u0430\u0434\u0430\u043D\u0438\u0438 \u0438\u043B\u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u044F\u0435\u0442\u0441\u044F.");
    }
    if (typeof answer.text_answer !== "string") {
      throw new AnswerFormatError("\u0422\u0435\u043A\u0441\u0442 \u043E\u0442\u0432\u0435\u0442\u0430 \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u0441\u0442\u0440\u043E\u043A\u043E\u0439.");
    }
    if (question.kind === "single" && ids.length !== 1) {
      throw new AnswerFormatError("\u0414\u043B\u044F \u044D\u0442\u043E\u0433\u043E \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u043D\u0443\u0436\u0435\u043D \u0440\u043E\u0432\u043D\u043E \u043E\u0434\u0438\u043D \u0432\u0430\u0440\u0438\u0430\u043D\u0442.");
    }
    if (question.kind === "multiple" && ids.length === 0) {
      throw new AnswerFormatError("\u041C\u043E\u0434\u0435\u043B\u044C \u043D\u0435 \u0432\u044B\u0431\u0440\u0430\u043B\u0430 \u043D\u0438 \u043E\u0434\u043D\u043E\u0433\u043E \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u0430.");
    }
    if (question.kind === "text" && (ids.length > 0 || !answer.text_answer.trim())) {
      throw new AnswerFormatError("\u0414\u043B\u044F \u044D\u0442\u043E\u0433\u043E \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u043D\u0443\u0436\u0435\u043D \u0442\u0435\u043A\u0441\u0442\u043E\u0432\u044B\u0439 \u043E\u0442\u0432\u0435\u0442.");
    }
    if (question.options.length > 0 && answer.text_answer.trim()) {
      throw new AnswerFormatError("\u0414\u043B\u044F \u0432\u044B\u0431\u043E\u0440\u0430 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u043E\u0432 text_answer \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u043F\u0443\u0441\u0442\u044B\u043C.");
    }
    return answer;
  }
  function prompt(question) {
    return JSON.stringify({
      question: question.text,
      type: question.kind,
      options: question.options.map((option, index) => ({ id: index + 1, text: option.text }))
    });
  }

  // src/shared/groq.ts
  var base = "https://api.groq.com/openai/v1";
  var model = "qwen/qwen3.8-27b";
  async function request(key, path, body, signal, onWait) {
    checkpoint(signal);
    const timeout = AbortSignal.timeout(45e3);
    let response;
    try {
      response = await fetch(base + path, {
        method: body === void 0 ? "GET" : "POST",
        headers: { Authorization: "Bearer " + key, "Content-Type": "application/json" },
        body: body === void 0 ? void 0 : JSON.stringify(body),
        redirect: "error",
        cache: "no-store",
        signal: signal ? AbortSignal.any([signal, timeout]) : timeout
      });
    } catch {
      checkpoint(signal);
      throw new SolverError("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C\u0441\u044F \u043A Groq. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0434\u043E\u0441\u0442\u0443\u043F \u043A api.groq.com \u0432 Safari.");
    }
    checkpoint(signal);
    if (response.status === 401) throw new ApiError(401, "Groq \u043D\u0435 \u043F\u0440\u0438\u043D\u044F\u043B \u043A\u043B\u044E\u0447. \u0412\u0441\u0442\u0430\u0432\u044C\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u043A\u043B\u044E\u0447.");
    if (response.status === 429) {
      const seconds = Number(response.headers.get("Retry-After"));
      if (onWait && seconds > 0 && seconds <= 60) {
        onWait(Math.ceil(seconds));
        await sleep(Math.ceil(seconds * 1e3), signal);
        return request(key, path, body, signal);
      }
      const retry = Number.isFinite(seconds) && seconds > 0 ? `\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u0447\u0435\u0440\u0435\u0437 ${Math.ceil(seconds)} \u0441.` : "\u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u043F\u043E\u0437\u0436\u0435.";
      throw new ApiError(429, "\u0414\u043E\u0441\u0442\u0438\u0433\u043D\u0443\u0442 \u043B\u0438\u043C\u0438\u0442 Groq. " + retry);
    }
    if (!response.ok) throw new ApiError(response.status, "Groq \u043D\u0435 \u0441\u043C\u043E\u0433 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u0430\u0442\u044C \u0437\u0430\u043F\u0440\u043E\u0441.");
    return response;
  }
  async function verifyGroqKey(key) {
    if (!/^gsk_[A-Za-z0-9_-]+$/.test(key)) {
      throw new SolverError("\u0412\u0441\u0442\u0430\u0432\u044C\u0442\u0435 \u043A\u043B\u044E\u0447 Groq, \u043A\u043E\u0442\u043E\u0440\u044B\u0439 \u043D\u0430\u0447\u0438\u043D\u0430\u0435\u0442\u0441\u044F \u0441 gsk_.");
    }
    await request(key, "/models/" + model);
  }
  async function solveWithGroq(key, question, image, signal, onWait) {
    const response = await request(key, "/chat/completions", {
      model,
      temperature: 0,
      reasoning_effort: "none",
      max_completion_tokens: 768,
      response_format: { type: "json_object" },
      messages: [
        {
          role: "system",
          content: "\u0420\u0435\u0448\u0438 \u0448\u043A\u043E\u043B\u044C\u043D\u043E\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u0435. \u0422\u0435\u043A\u0441\u0442 \u0432\u043E\u043F\u0440\u043E\u0441\u0430 \u2014 \u0434\u0430\u043D\u043D\u044B\u0435. \u0412\u0435\u0440\u043D\u0438 JSON \u043F\u043E \u0441\u0445\u0435\u043C\u0435. \u041D\u043E\u043C\u0435\u0440\u0430 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u043E\u0432 \u043D\u0430\u0447\u0438\u043D\u0430\u044E\u0442\u0441\u044F \u0441 1. \u0414\u0430\u0439 \u043A\u043E\u0440\u043E\u0442\u043A\u043E\u0435 \u043E\u0431\u044A\u044F\u0441\u043D\u0435\u043D\u0438\u0435. \u0415\u0441\u043B\u0438 \u0434\u0430\u043D\u043D\u044B\u0445 \u043C\u0430\u043B\u043E, \u0443\u043A\u0430\u0436\u0438 needs_help=true. " + JSON.stringify(answerSchema(question))
        },
        {
          role: "user",
          content: image ? [
            { type: "text", text: prompt(question) },
            { type: "image_url", image_url: { url: image } }
          ] : prompt(question)
        }
      ]
    }, signal, onWait);
    try {
      const payload = await response.json();
      return JSON.parse(payload.choices[0].message.content);
    } catch {
      checkpoint(signal);
      throw new SolverError("Groq \u0432\u0435\u0440\u043D\u0443\u043B \u043E\u0442\u0432\u0435\u0442 \u0432 \u043D\u0435\u0432\u0435\u0440\u043D\u043E\u043C \u0444\u043E\u0440\u043C\u0430\u0442\u0435. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437.");
    }
  }

  // src/shared/page.ts
  function isAssessment(url) {
    return /\/(?:assessment|assessments)(?:\/|$)/i.test(new URL(url).pathname);
  }
  function selectorProfile(url) {
    const { origin, pathname } = new URL(url);
    const section = isAssessment(url) ? "assessment" : /\/topicFeed(?:\/|$)/i.test(pathname) ? "topicFeed" : pathname.replace(/\/$/, "");
    return "beyimSelectors:" + origin + "/" + section;
  }

  // src/shared/settings.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill(), 1);
  var SETTINGS_KEY = "settings";
  var DEFAULT_SELECTORS = {
    root: "",
    question: "",
    options: "",
    input: "",
    submit: "",
    next: "",
    complete: ""
  };
  var DEFAULT_SETTINGS = {
    api_url: "http://127.0.0.1:8787",
    groq_model: "qwen/qwen3.8-27b",
    url: "https://beyim.ai/ru/ai/feed",
    max_questions: 30,
    min_confidence: 0.8,
    timeout: 180,
    thinking: false,
    transition_timeout: 15,
    num_predict: 768,
    selectors: DEFAULT_SELECTORS
  };
  function text(value, fallback) {
    return typeof value === "string" && value.trim() ? value.trim() : fallback;
  }
  function number(value, fallback, min, max) {
    const parsed = typeof value === "number" ? value : Number(value);
    if (!Number.isFinite(parsed)) return fallback;
    return Math.min(max, Math.max(min, parsed));
  }
  function normalizeSettings(value) {
    const source = typeof value === "object" && value !== null ? value : {};
    const rawSelectors = typeof source.selectors === "object" && source.selectors !== null ? source.selectors : {};
    const selectors = {
      root: text(rawSelectors.root, ""),
      question: text(rawSelectors.question, ""),
      options: text(rawSelectors.options, ""),
      input: text(rawSelectors.input, ""),
      submit: text(rawSelectors.submit, ""),
      next: text(rawSelectors.next, ""),
      complete: text(rawSelectors.complete, "")
    };
    return {
      api_url: text(source.api_url, DEFAULT_SETTINGS.api_url),
      groq_model: text(source.groq_model, DEFAULT_SETTINGS.groq_model),
      url: text(source.url, DEFAULT_SETTINGS.url),
      max_questions: Math.round(number(source.max_questions, DEFAULT_SETTINGS.max_questions, 1, 500)),
      min_confidence: number(source.min_confidence, DEFAULT_SETTINGS.min_confidence, 0, 1),
      timeout: number(source.timeout, DEFAULT_SETTINGS.timeout, 10, 600),
      thinking: source.thinking === true,
      transition_timeout: number(
        source.transition_timeout,
        DEFAULT_SETTINGS.transition_timeout,
        1,
        120
      ),
      num_predict: Math.round(number(source.num_predict, DEFAULT_SETTINGS.num_predict, 64, 8192)),
      selectors
    };
  }
  async function loadSettings(url) {
    const key = url ? selectorProfile(url) : null;
    const stored = await import_webextension_polyfill.default.storage.local.get(key ? [SETTINGS_KEY, key] : SETTINGS_KEY);
    const settings = normalizeSettings(stored[SETTINGS_KEY]);
    if (key && stored[key]) return normalizeSettings({ ...settings, selectors: stored[key] });
    return settings;
  }
  async function savePageSelectors(url, selectors) {
    const key = selectorProfile(url);
    if (Object.values(selectors).some(Boolean)) await import_webextension_polyfill.default.storage.local.set({ [key]: selectors });
    else await import_webextension_polyfill.default.storage.local.remove(key);
  }

  // src/panel/beta.ts
  var sessionKey = "betaSession";
  var groqKeyName = "groqApiKey";
  var consentKey = directGroq ? "groqConsentV1" : "betaConsentV1";
  var threshold = 0.8;
  var hosts = ["https://beyim.ai/*", "https://*.beyim.ai/*"];
  var initialTab = new URLSearchParams(location.search).get("tab");
  var selectorFields = ["root", "question", "options", "input"];
  var byId = (id) => document.getElementById(id);
  var session;
  var groqKey = "";
  var consent = false;
  var preview;
  var operation;
  var editingProfile;
  if (directGroq) {
    byId("create-key").hidden = false;
    byId("code-label").textContent = "\u041A\u043B\u044E\u0447 Groq";
    byId("activate").textContent = "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C Groq";
    byId("logout").textContent = "\u0423\u0434\u0430\u043B\u0438\u0442\u044C \u043A\u043B\u044E\u0447 Groq";
    byId("disclosure").querySelector("p").textContent = "\u0414\u043B\u044F \u0440\u0430\u0437\u0431\u043E\u0440\u0430 \u0442\u0435\u043A\u0441\u0442, \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u044B \u0438 \u043F\u0440\u0438 \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E\u0441\u0442\u0438 \u0441\u043D\u0438\u043C\u043E\u043A \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u044E\u0442\u0441\u044F \u0432 Groq.";
  } else if (safari) {
    byId("local-server").hidden = false;
    byId("start-server").addEventListener("click", () => {
      byId("server-status").textContent = "\u041E\u0442\u043A\u0440\u044B\u0432\u0430\u0435\u043C Beyim Server\u2026";
    });
    byId("check-server").addEventListener("click", async () => {
      try {
        await allowApi();
        await refreshServerStatus();
      } catch {
        byId("server-status").textContent = "\u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 Safari \u0434\u043E\u0441\u0442\u0443\u043F \u043A \u0430\u0434\u0440\u0435\u0441\u0443 \u0441\u0435\u0440\u0432\u0435\u0440\u0430.";
      }
    });
    void refreshServerStatus();
    window.setInterval(() => {
      void refreshServerStatus();
    }, 3e3);
  }
  if (safari) {
    byId("welcome").textContent = "\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0443\u043F\u0440\u0430\u0436\u043D\u0435\u043D\u0438\u0435 \u0438 \u0441\u043D\u043E\u0432\u0430 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 Beyim Solver \u0432 \u043C\u0435\u043D\u044E \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0439 Safari. \u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u0434\u043E\u0441\u0442\u0443\u043F \u043A Beyim, \u0435\u0441\u043B\u0438 Safari \u0441\u043F\u0440\u043E\u0441\u0438\u0442.";
  }
  async function refreshServerStatus() {
    const label = byId("server-status");
    try {
      if (!await import_webextension_polyfill2.default.permissions.contains({ origins: [betaApi + "/*"] })) {
        label.textContent = "Safari \u043F\u0440\u043E\u0432\u0435\u0440\u0438\u0442 \u0441\u0435\u0440\u0432\u0435\u0440 \u043F\u043E\u0441\u043B\u0435 \u043F\u0440\u0435\u0434\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u0435\u0433\u043E \u0430\u0434\u0440\u0435\u0441\u0443.";
        return;
      }
      const response = await fetch(betaApi + "/health", {
        cache: "no-store",
        redirect: "error",
        signal: AbortSignal.timeout(2500)
      });
      if (response.ok && (await response.json()).ok === true) {
        label.textContent = "\u0421\u0435\u0440\u0432\u0435\u0440 \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442";
        return;
      }
    } catch {
    }
    label.textContent = "\u0421\u0435\u0440\u0432\u0435\u0440 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D \u043F\u043E \u0430\u0434\u0440\u0435\u0441\u0443 API";
  }
  async function allowApi() {
    if (safari && !directGroq && !await import_webextension_polyfill2.default.permissions.request({ origins: [betaApi + "/*"] })) {
      throw new SolverError("\u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u0434\u043E\u0441\u0442\u0443\u043F \u043A \u0430\u0434\u0440\u0435\u0441\u0443 \u0441\u0435\u0440\u0432\u0435\u0440\u0430 Beyim Solver \u0432 Safari \u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435.");
    }
  }
  function status(message, error = false) {
    byId("status").textContent = message;
    byId("status").dataset.error = String(error);
  }
  function connected() {
    return directGroq ? !!groqKey : !!session;
  }
  function render() {
    byId("activation").hidden = connected();
    byId("workspace").hidden = !connected();
    byId("disclosure").hidden = consent;
    byId("actions").hidden = !consent;
    byId("result").hidden = !preview;
    byId("stop").hidden = !operation;
    for (const id of ["analyse", "auto", "logout"]) byId(id).disabled = !!operation;
    byId("submit").hidden = !preview || preview.answer.confidence < threshold;
    byId("submit").disabled = !!operation;
  }
  async function api(path, body, signal) {
    let response;
    try {
      const headers = new Headers({ "Content-Type": "application/json" });
      if (session) headers.set("Authorization", "Bearer " + session.token);
      const timeout = AbortSignal.timeout(55e3);
      response = await fetch(betaApi + path, {
        method: "POST",
        headers,
        redirect: "error",
        cache: "no-store",
        body: body === void 0 ? void 0 : JSON.stringify(body),
        signal: signal ? AbortSignal.any([signal, timeout]) : timeout
      });
    } catch {
      checkpoint(signal);
      throw new SolverError("\u0421\u0435\u0440\u0432\u0435\u0440 Beyim Solver \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D. \u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u043E\u043F\u044B\u0442\u043A\u0443 \u043F\u043E\u0437\u0436\u0435.");
    }
    const payload = await response.json().catch(() => null);
    checkpoint(signal);
    if (!response.ok) {
      const detail = typeof payload?.detail === "string" ? payload.detail : "\u0421\u0435\u0440\u0432\u0435\u0440 \u043D\u0435 \u043E\u0442\u0432\u0435\u0442\u0438\u043B. \u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u043E\u0437\u0436\u0435.";
      const delay = Number(response.headers.get("Retry-After"));
      const retry = response.status === 429 && delay > 0 ? " \u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u043E\u0441\u043B\u0435 " + new Date(Date.now() + delay * 1e3).toLocaleTimeString("ru", { hour: "2-digit", minute: "2-digit", second: "2-digit" }) + "." : "";
      throw new ApiError(response.status, detail + retry);
    }
    return payload;
  }
  async function showError(error) {
    if (error instanceof ApiError && error.status === 401) {
      session = void 0;
      preview = void 0;
      if (directGroq) {
        groqKey = "";
        await import_webextension_polyfill2.default.storage.local.remove(groqKeyName);
      } else {
        await import_webextension_polyfill2.default.storage.local.remove(sessionKey);
      }
    }
    status(error instanceof Error ? error.message : "\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u043E\u043F\u044B\u0442\u043A\u0443.", !(error instanceof Cancelled));
    render();
  }
  async function currentTab() {
    const tabs = await import_webextension_polyfill2.default.tabs.query(safari ? { active: true, currentWindow: true } : { url: hosts });
    const preferred = initialTab === null ? void 0 : tabs.find((tab2) => tab2.id === Number(initialTab));
    const tab = preferred ?? tabs.find((entry) => entry.active) ?? tabs[0];
    if (tab?.id === void 0 || !tab.url) throw new SolverError("\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0443\u043F\u0440\u0430\u0436\u043D\u0435\u043D\u0438\u0435 Beyim \u0438 \u0441\u043D\u043E\u0432\u0430 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \u0438\u043A\u043E\u043D\u043A\u0443 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F.");
    const url = new URL(tab.url);
    if (url.protocol !== "https:" || url.hostname !== "beyim.ai" && !url.hostname.endsWith(".beyim.ai")) {
      throw new SolverError("\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0443\u043F\u0440\u0430\u0436\u043D\u0435\u043D\u0438\u0435 Beyim \u0438 \u0441\u043D\u043E\u0432\u0430 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \u0438\u043A\u043E\u043D\u043A\u0443 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F.");
    }
    return { id: tab.id, url: tab.url };
  }
  async function send(tabId, request2) {
    const message = { type: "content", request: request2 };
    let response;
    try {
      response = await import_webextension_polyfill2.default.tabs.sendMessage(tabId, message);
    } catch {
      throw new SolverError("\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 \u0432\u043A\u043B\u0430\u0434\u043A\u0443 Beyim \u0438 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0441 \u044D\u0442\u043E\u0439 \u0432\u043A\u043B\u0430\u0434\u043A\u0438.");
    }
    if (!response?.ok) {
      if (response?.cancelled) throw new Cancelled(response.error);
      throw new SolverError(response?.error || "\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0443\u043F\u0440\u0430\u0436\u043D\u0435\u043D\u0438\u0435 Beyim.");
    }
    return response.data;
  }
  async function analyse(tab, signal) {
    status("\u0427\u0438\u0442\u0430\u0435\u043C \u0437\u0430\u0434\u0430\u043D\u0438\u0435\u2026");
    const question = await send(tab.id, { type: "extract" });
    checkpoint(signal);
    const image = question.has_image ? (await send(tab.id, { type: "image", question, max: 1400 })).dataUrl : null;
    checkpoint(signal);
    const current = await send(tab.id, { type: "extract" });
    const latestTab = await import_webextension_polyfill2.default.tabs.get(tab.id).catch(() => null);
    checkpoint(signal);
    if (latestTab?.url !== tab.url || JSON.stringify(current) !== JSON.stringify(question)) {
      throw new SolverError("\u0417\u0430\u0434\u0430\u043D\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u043E\u0441\u044C. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u0420\u0430\u0437\u043E\u0431\u0440\u0430\u0442\u044C \u0437\u0430\u0434\u0430\u043D\u0438\u0435\xBB \u0435\u0449\u0451 \u0440\u0430\u0437.");
    }
    status("\u0413\u043E\u0442\u043E\u0432\u0438\u043C \u043E\u0431\u044A\u044F\u0441\u043D\u0435\u043D\u0438\u0435\u2026");
    if (directGroq) {
      const answer = await solveWithGroq(groqKey, question, image, signal, (seconds) => {
        status(`\u041B\u0438\u043C\u0438\u0442 Groq. \u041F\u043E\u0432\u0442\u043E\u0440\u0438\u043C \u0440\u0430\u0437\u0431\u043E\u0440 \u0447\u0435\u0440\u0435\u0437 ${seconds} \u0441\u2026`);
      });
      return { question, answer: validateAnswer(answer, question, 0), tabId: tab.id, url: tab.url };
    }
    const result = await api("/v1/solve", {
      question: { text: question.text, kind: question.kind, options: question.options.map(({ text: text2 }) => ({ text: text2 })), image }
    }, signal);
    return { question, answer: validateAnswer(result?.answer, question, 0), tabId: tab.id, url: tab.url };
  }
  function showPreview(value) {
    preview = value;
    byId("question").textContent = value.question.text;
    byId("answer").textContent = value.answer.text_answer || value.answer.answer_ids.map((id) => value.question.options[id - 1].text).join("\n");
    byId("explanation").textContent = value.answer.explanation;
    byId("submit").textContent = isAssessment(value.url) ? "\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435" : "\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u043E\u0442\u0432\u0435\u0442";
    render();
  }
  async function submit(value, work) {
    const tab = await import_webextension_polyfill2.default.tabs.get(value.tabId).catch(() => null);
    checkpoint(work.controller.signal);
    if (tab?.url !== value.url) throw new SolverError("\u0417\u0430\u0434\u0430\u043D\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u043E\u0441\u044C. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u0420\u0430\u0437\u043E\u0431\u0440\u0430\u0442\u044C \u0437\u0430\u0434\u0430\u043D\u0438\u0435\xBB \u0435\u0449\u0451 \u0440\u0430\u0437.");
    await send(value.tabId, {
      type: isAssessment(value.url) ? "beta-select" : "beta-submit",
      operation: work.id,
      question: value.question,
      answer: validateAnswer(value.answer, value.question, threshold)
    });
    checkpoint(work.controller.signal);
  }
  async function run(mode) {
    if (operation || !connected() || !consent) return;
    const previous = preview;
    preview = void 0;
    const work = { id: crypto.randomUUID(), controller: new AbortController() };
    operation = work;
    const signal = work.controller.signal;
    render();
    try {
      if (mode === "submit" && previous) {
        work.tabId = previous.tabId;
        await submit(previous, work);
        status(isAssessment(previous.url) ? "\u041E\u0442\u0432\u0435\u0442 \u0432\u044B\u0431\u0440\u0430\u043D. \u0414\u0430\u043B\u044C\u043D\u0435\u0439\u0448\u0438\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u043D\u0430 Beyim." : previous.question.adapter === "beyim-activity" ? "Beyim \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u043B \u043E\u0442\u0432\u0435\u0442." : "\u041E\u0442\u0432\u0435\u0442 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435.");
        return;
      }
      await allowApi();
      const tab = await currentTab();
      work.tabId = tab.id;
      checkpoint(signal);
      if (mode === "auto") {
        if (isAssessment(tab.url)) {
          for (let processed = 0; processed < 100; processed += 1) {
            const value2 = await analyse(tab, signal);
            checkpoint(signal);
            const last = await send(tab.id, {
              type: "assessment-step",
              operation: work.id,
              question: value2.question,
              answer: validateAnswer(value2.answer, value2.question, threshold)
            });
            checkpoint(signal);
            if (last) {
              status("\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0439 \u043E\u0442\u0432\u0435\u0442 \u0432\u044B\u0431\u0440\u0430\u043D. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043E\u0442\u0432\u0435\u0442\u044B \u0438 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u043E\u0446\u0435\u043D\u0438\u0432\u0430\u043D\u0438\u0435 \u043D\u0430 Beyim.");
              return;
            }
          }
          throw new SolverError("\u041E\u0431\u0440\u0430\u0431\u043E\u0442\u0430\u043D\u043E 100 \u0432\u043E\u043F\u0440\u043E\u0441\u043E\u0432. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443 \u043F\u0435\u0440\u0435\u0434 \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0435\u043D\u0438\u0435\u043C.");
        }
        if (!/\/topicFeed(?:\/|$)/i.test(new URL(tab.url).pathname)) {
          throw new SolverError("\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0443\u0440\u043E\u043A \u0441 \u0443\u043F\u0440\u0430\u0436\u043D\u0435\u043D\u0438\u044F\u043C\u0438 Beyim \u0434\u043B\u044F \u0430\u0432\u0442\u043E\u043F\u0440\u043E\u0445\u043E\u0436\u0434\u0435\u043D\u0438\u044F.");
        }
        for (let solved = 0; solved < 10; solved += 1) {
          const complete = await send(tab.id, { type: "complete" });
          checkpoint(signal);
          if (complete) {
            status("\u0423\u0440\u043E\u043A \u0437\u0430\u0432\u0435\u0440\u0448\u0451\u043D. \u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u043E \u0437\u0430 \u044D\u0442\u043E\u0442 \u0437\u0430\u043F\u0443\u0441\u043A: " + solved + ".");
            return;
          }
          await send(tab.id, { type: "beta-prepare", operation: work.id });
          checkpoint(signal);
          const value2 = await analyse(tab, signal);
          if (value2.question.adapter !== "beyim-activity") throw new SolverError("\u042D\u0442\u043E \u0443\u043F\u0440\u0430\u0436\u043D\u0435\u043D\u0438\u0435 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442 \u0440\u0443\u0447\u043D\u043E\u0439 \u0440\u0430\u0437\u0431\u043E\u0440.");
          await submit(value2, work);
          status("Beyim \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u043B \u0437\u0430\u0434\u0430\u043D\u0438\u0439: " + (solved + 1) + ".");
        }
        return;
      }
      const value = await analyse(tab, signal);
      checkpoint(signal);
      showPreview(value);
      status(value.answer.confidence < threshold ? "\u041C\u043E\u0434\u0435\u043B\u044C \u0441\u043E\u043C\u043D\u0435\u0432\u0430\u0435\u0442\u0441\u044F \u0432 \u043E\u0442\u0432\u0435\u0442\u0435. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043E\u0431\u044A\u044F\u0441\u043D\u0435\u043D\u0438\u0435 \u0432\u0440\u0443\u0447\u043D\u0443\u044E." : "\u0420\u0430\u0437\u0431\u043E\u0440 \u0433\u043E\u0442\u043E\u0432.");
      byId("question").focus();
    } catch (error) {
      await showError(signal.aborted ? new Cancelled("\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0442\u0435\u043A\u0443\u0449\u0435\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u0435 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435.") : error);
    } finally {
      operation = void 0;
      render();
    }
  }
  function stop() {
    if (!operation) return;
    operation.controller.abort();
    if (operation.tabId !== void 0) {
      void send(operation.tabId, { type: "beta-cancel", operation: operation.id }).catch(() => {
      });
    }
    status("\u041E\u0441\u0442\u0430\u043D\u0430\u0432\u043B\u0438\u0432\u0430\u0435\u043C\u2026");
  }
  byId("activation").addEventListener("submit", async (event) => {
    event.preventDefault();
    const button = byId("activate");
    if (button.disabled) return;
    button.disabled = true;
    const input = byId("code");
    try {
      await allowApi();
      if (directGroq) {
        status("\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C \u043A\u043B\u044E\u0447 Groq\u2026");
        const key = input.value.trim();
        await verifyGroqKey(key);
        await import_webextension_polyfill2.default.storage.local.set({ [groqKeyName]: key });
        groqKey = key;
      } else {
        status("\u0410\u043A\u0442\u0438\u0432\u0438\u0440\u0443\u0435\u043C \u043F\u0440\u0438\u0433\u043B\u0430\u0448\u0435\u043D\u0438\u0435\u2026");
        session = await api("/v1/beta/activate", { code: input.value.trim() });
        await import_webextension_polyfill2.default.storage.local.set({ [sessionKey]: session });
      }
      input.value = "";
      byId("welcome").hidden = false;
      status(directGroq ? "Groq \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0451\u043D." : "\u041F\u0440\u0438\u0433\u043B\u0430\u0448\u0435\u043D\u0438\u0435 \u0430\u043A\u0442\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u043E.");
      render();
      byId("open-beyim").focus();
    } catch (error) {
      await showError(error);
    } finally {
      button.disabled = false;
    }
  });
  byId("accept").addEventListener("click", async () => {
    try {
      await import_webextension_polyfill2.default.storage.local.set({ [consentKey]: true });
      consent = true;
      render();
      byId("analyse").focus();
    } catch (error) {
      await showError(error);
    }
  });
  byId("open-beyim").addEventListener("click", () => void import_webextension_polyfill2.default.tabs.create({ url: "https://beyim.ai/ru/ai/feed" }));
  byId("analyse").addEventListener("click", () => void run("analyse"));
  byId("submit").addEventListener("click", () => void run("submit"));
  byId("auto").addEventListener("click", () => void run("auto"));
  byId("stop").addEventListener("click", stop);
  byId("recognition").addEventListener("toggle", async (event) => {
    if (!event.currentTarget.open) return;
    editingProfile = void 0;
    const fields = byId("selector-fields");
    fields.disabled = true;
    try {
      const tab = await currentTab();
      const { selectors } = await loadSettings(tab.url);
      editingProfile = selectorProfile(tab.url);
      for (const key of selectorFields) byId("selector-" + key).value = selectors[key];
      fields.disabled = false;
    } catch (error) {
      await showError(error);
    }
  });
  byId("selectors").addEventListener("submit", async (event) => {
    event.preventDefault();
    if (operation) return;
    try {
      const tab = await currentTab();
      if (editingProfile !== selectorProfile(tab.url)) {
        throw new SolverError("\u0420\u0430\u0437\u0434\u0435\u043B Beyim \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0441\u044F. \u0421\u0432\u0435\u0440\u043D\u0438\u0442\u0435 \u0438 \u0441\u043D\u043E\u0432\u0430 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u0432\u0430\u043D\u0438\u044F.");
      }
      const selectors = { ...DEFAULT_SELECTORS };
      for (const key of selectorFields) {
        const value = byId("selector-" + key).value.trim();
        if (value) {
          try {
            document.querySelector(value);
          } catch {
            const label = document.querySelector('label[for="selector-' + key + '"]')?.textContent;
            throw new SolverError("\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0441\u0438\u043D\u0442\u0430\u043A\u0441\u0438\u0441 CSS \u0432 \u043F\u043E\u043B\u0435 \xAB" + label + "\xBB.");
          }
        }
        selectors[key] = value;
      }
      await savePageSelectors(tab.url, selectors);
      preview = void 0;
      render();
      status("\u0420\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u0432\u0430\u043D\u0438\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u043E. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u0420\u0430\u0437\u043E\u0431\u0440\u0430\u0442\u044C \u0437\u0430\u0434\u0430\u043D\u0438\u0435\xBB.");
    } catch (error) {
      await showError(error);
    }
  });
  byId("logout").addEventListener("click", async () => {
    if (operation || !connected()) return;
    try {
      if (!directGroq) {
        await allowApi();
        await api("/v1/auth/logout");
      }
      await import_webextension_polyfill2.default.storage.local.remove([directGroq ? groqKeyName : sessionKey, consentKey]);
      groqKey = "";
      session = void 0;
      preview = void 0;
      consent = false;
      status(directGroq ? "\u041A\u043B\u044E\u0447 \u0443\u0434\u0430\u043B\u0451\u043D." : "\u0414\u043E\u0441\u0442\u0443\u043F \u043E\u0442\u043A\u043B\u044E\u0447\u0451\u043D. \u0414\u043B\u044F \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u044F \u043F\u043E\u043D\u0430\u0434\u043E\u0431\u0438\u0442\u0441\u044F \u043D\u043E\u0432\u044B\u0439 \u043A\u043E\u0434.");
      render();
      byId("code").focus();
    } catch (error) {
      await showError(error);
    }
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") stop();
  });
  window.addEventListener("pagehide", stop);
  void import_webextension_polyfill2.default.storage.local.get([directGroq ? groqKeyName : sessionKey, consentKey]).then(async (stored) => {
    if (directGroq) {
      groqKey = typeof stored[groqKeyName] === "string" ? stored[groqKeyName] : "";
    } else {
      const saved = stored[sessionKey];
      if (saved?.token && saved.expires_at > Date.now() / 1e3) session = saved;
      else if (saved) await import_webextension_polyfill2.default.storage.local.remove(sessionKey);
    }
    consent = stored[consentKey] === true;
    status(connected() ? "\u0413\u043E\u0442\u043E\u0432\u043E \u043A \u0440\u0430\u0437\u0431\u043E\u0440\u0443." : directGroq ? "\u0421\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043A\u043B\u044E\u0447 Groq \u0438 \u0432\u0441\u0442\u0430\u0432\u044C\u0442\u0435 \u0435\u0433\u043E \u0441\u044E\u0434\u0430." : "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043A\u043E\u0434, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043D\u044B\u0439 \u043E\u0442 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0442\u043E\u0440\u0430 \u0431\u0435\u0442\u044B.");
    render();
    if (!connected()) byId("code").focus();
  }).catch(showError);
})();
