"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/content/index.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill(), 1);

  // src/shared/errors.ts
  var SolverError = class extends Error {
    name = "SolverError";
  };
  var Cancelled = class extends SolverError {
    name = "Cancelled";
  };

  // src/shared/settings.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill(), 1);

  // src/shared/page.ts
  function isAssessment(url) {
    return /\/(?:assessment|assessments)(?:\/|$)/i.test(new URL(url).pathname);
  }
  function selectorProfile(url) {
    const { origin, pathname } = new URL(url);
    const section = isAssessment(url) ? "assessment" : /\/topicFeed(?:\/|$)/i.test(pathname) ? "topicFeed" : pathname.replace(/\/$/, "");
    return "beyimSelectors:" + origin + "/" + section;
  }

  // src/shared/settings.ts
  var SETTINGS_KEY = "settings";
  var DEFAULT_SELECTORS = {
    root: "",
    question: "",
    options: "",
    input: "",
    submit: "",
    next: "",
    complete: ""
  };
  var DEFAULT_SETTINGS = {
    api_url: "http://127.0.0.1:8787",
    groq_model: "qwen/qwen3.8-27b",
    url: "https://beyim.ai/ru/ai/feed",
    max_questions: 30,
    min_confidence: 0.8,
    timeout: 180,
    thinking: false,
    transition_timeout: 15,
    num_predict: 768,
    selectors: DEFAULT_SELECTORS
  };
  function text(value, fallback) {
    return typeof value === "string" && value.trim() ? value.trim() : fallback;
  }
  function number(value, fallback, min, max) {
    const parsed = typeof value === "number" ? value : Number(value);
    if (!Number.isFinite(parsed)) return fallback;
    return Math.min(max, Math.max(min, parsed));
  }
  function normalizeSettings(value) {
    const source = typeof value === "object" && value !== null ? value : {};
    const rawSelectors = typeof source.selectors === "object" && source.selectors !== null ? source.selectors : {};
    const selectors = {
      root: text(rawSelectors.root, ""),
      question: text(rawSelectors.question, ""),
      options: text(rawSelectors.options, ""),
      input: text(rawSelectors.input, ""),
      submit: text(rawSelectors.submit, ""),
      next: text(rawSelectors.next, ""),
      complete: text(rawSelectors.complete, "")
    };
    return {
      api_url: text(source.api_url, DEFAULT_SETTINGS.api_url),
      groq_model: text(source.groq_model, DEFAULT_SETTINGS.groq_model),
      url: text(source.url, DEFAULT_SETTINGS.url),
      max_questions: Math.round(number(source.max_questions, DEFAULT_SETTINGS.max_questions, 1, 500)),
      min_confidence: number(source.min_confidence, DEFAULT_SETTINGS.min_confidence, 0, 1),
      timeout: number(source.timeout, DEFAULT_SETTINGS.timeout, 10, 600),
      thinking: source.thinking === true,
      transition_timeout: number(
        source.transition_timeout,
        DEFAULT_SETTINGS.transition_timeout,
        1,
        120
      ),
      num_predict: Math.round(number(source.num_predict, DEFAULT_SETTINGS.num_predict, 64, 8192)),
      selectors
    };
  }
  async function loadSettings(url) {
    const key = url ? selectorProfile(url) : null;
    const stored = await import_webextension_polyfill.default.storage.local.get(key ? [SETTINGS_KEY, key] : SETTINGS_KEY);
    const settings = normalizeSettings(stored[SETTINGS_KEY]);
    if (key && stored[key]) return normalizeSettings({ ...settings, selectors: stored[key] });
    return settings;
  }

  // src/content/index.ts
  var SUBMIT = /^(Проверить|Проверить ответ|Ответить|Отправить ответ|Тексеру|Жауап беру|Check|Check answer|Submit)$/i;
  var NEXT = /^(Далее|Следующий вопрос|Следующее задание|Продолжить|Келесі|Жалғастыру|Next|Continue)$/i;
  var COMPLETE = /^(Тест заверш[её]н|Урок заверш[её]н|Вы завершили тест|Тестілеу аяқталды|Test completed|Lesson completed)[.!]?$/i;
  var CONTROL = "input[type=radio],input[type=checkbox],[role=radio],[role=checkbox]";
  var TEXT_CONTROL = "textarea,input[type=text],input[type=number],input:not([type])";
  var QUESTION_CONTAINER = "fieldset,[data-question],[data-question-id],[data-testid=question],[data-testid=assessment-question]";
  var QUESTION_TEXT = "[data-question-text],[data-testid=question-text],.question-text,.question-title,legend";
  var revisions = /* @__PURE__ */ new WeakMap();
  var submitted = /* @__PURE__ */ new WeakMap();
  var cancelled = /* @__PURE__ */ new Map();
  function revision(root) {
    let id = revisions.get(root);
    if (!id) {
      id = crypto.randomUUID();
      revisions.set(root, id);
    }
    return location.href + "#" + id;
  }
  function visible(element) {
    return !!element && element.getClientRects().length > 0 && getComputedStyle(element).visibility !== "hidden";
  }
  function all(root, selector) {
    return selector ? [...root.querySelectorAll(selector)].filter(visible) : [];
  }
  function text2(element) {
    const value = element?.innerText || element?.textContent || "";
    return value.replace(/[ \t]+/g, " ").replace(/\n\s*\n/g, "\n").trim();
  }
  function unique(root, selector) {
    const found = all(root, selector);
    if (found.length !== 1) {
      throw new SolverError(`\u0421\u0435\u043B\u0435\u043A\u0442\u043E\u0440 \xAB${selector}\xBB: \u043D\u0430\u0439\u0434\u0435\u043D\u043E ${found.length}, \u043D\u0443\u0436\u0435\u043D \u043E\u0434\u0438\u043D \u044D\u043B\u0435\u043C\u0435\u043D\u0442.`);
    }
    return found[0];
  }
  function path(element) {
    if (element.id && document.querySelectorAll("#" + CSS.escape(element.id)).length === 1) {
      return "#" + CSS.escape(element.id);
    }
    const parts = [];
    let current = element;
    while (current && current !== document.documentElement) {
      const node = current;
      const tag = node.tagName.toLowerCase();
      const parent = node.parentElement;
      if (!parent) break;
      const siblings = [...parent.children].filter((child) => child.tagName === node.tagName);
      parts.unshift(`${tag}:nth-of-type(${siblings.indexOf(node) + 1})`);
      current = parent;
    }
    return "html > " + parts.join(" > ");
  }
  function labelsOf(element) {
    if (element instanceof HTMLInputElement || element instanceof HTMLSelectElement || element instanceof HTMLTextAreaElement) {
      return element.labels ? [...element.labels] : [];
    }
    return [];
  }
  function labelFor(element) {
    const labels = labelsOf(element);
    if (labels.length) return labels.map(text2).join(" ");
    const labelled = element.getAttribute("aria-labelledby");
    if (labelled) {
      return labelled.split(/\s+/).map((id) => text2(document.getElementById(id))).join(" ");
    }
    return element.getAttribute("aria-label") || text2(element.closest("label")) || text2(element);
  }
  function usable(element) {
    return visible(element) || labelsOf(element).some(visible);
  }
  function sameQuestion(left, right) {
    return left.text === right.text && left.kind === right.kind && left.options.length === right.options.length && left.options.every((option, index) => option.text === right.options[index]?.text);
  }
  function genericRoot(assessment) {
    const controls = (element) => [...element.querySelectorAll(CONTROL)].filter(usable);
    const candidates = all(document, QUESTION_CONTAINER).filter(
      (element) => controls(element).length >= 2 || assessment && all(element, TEXT_CONTROL).length === 1
    );
    const roots = candidates.filter((element) => !candidates.some((other) => other !== element && element.contains(other)));
    const groups = all(document, "[role=radiogroup],[role=group]").filter(
      (element) => controls(element).length >= 2 && !roots.some((root) => root.contains(element))
    );
    for (const group of groups) {
      if (group.hasAttribute("aria-labelledby") || group.hasAttribute("aria-label") || all(group, QUESTION_TEXT).length) {
        roots.push(group);
        continue;
      }
      const parent = group.parentElement;
      roots.push(parent && all(parent, QUESTION_TEXT + ",h1,h2,h3,h4").length === 1 && controls(parent).length === controls(group).length ? parent : group);
    }
    const active = roots.filter((root) => root.matches("[data-active=true],[aria-current=true]"));
    if (active.length === 1) return active[0];
    if (roots.length === 1) return roots[0];
    throw new SolverError(roots.length ? "\u041D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0432\u043E\u043F\u0440\u043E\u0441\u043E\u0432. \u0423\u043A\u0430\u0436\u0438\u0442\u0435 CSS-\u0441\u0435\u043B\u0435\u043A\u0442\u043E\u0440 \u043E\u0434\u043D\u043E\u0433\u043E \u0432\u043E\u043F\u0440\u043E\u0441\u0430 \u0432 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430\u0445 \u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u0432\u0430\u043D\u0438\u044F." : "\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D \u0431\u043B\u043E\u043A \u0437\u0430\u0434\u0430\u043D\u0438\u044F. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0432\u043E\u043F\u0440\u043E\u0441 \u0438\u043B\u0438 \u0443\u043A\u0430\u0436\u0438\u0442\u0435 \u0435\u0433\u043E CSS-\u0441\u0435\u043B\u0435\u043A\u0442\u043E\u0440 \u0432 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430\u0445 \u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u0432\u0430\u043D\u0438\u044F.");
  }
  function genericPrompt(root) {
    const labelled = root.getAttribute("aria-labelledby");
    if (labelled) {
      const labels = labelled.trim().split(/\s+/).map((id) => document.getElementById(id));
      if (labels.every(Boolean)) return labels.map(text2).join("\n");
    }
    const prompts = all(root, QUESTION_TEXT);
    const headings = prompts.length ? prompts : all(root, "h1,h2,h3,h4");
    if (headings.length === 1) return text2(headings[0]);
    if (!headings.length && root.hasAttribute("aria-label")) return root.getAttribute("aria-label") ?? "";
    throw new SolverError("\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D \u043E\u0434\u043D\u043E\u0437\u043D\u0430\u0447\u043D\u044B\u0439 \u0442\u0435\u043A\u0441\u0442 \u0432\u043E\u043F\u0440\u043E\u0441\u0430. \u0423\u043A\u0430\u0436\u0438\u0442\u0435 CSS-\u0441\u0435\u043B\u0435\u043A\u0442\u043E\u0440 \u0442\u0435\u043A\u0441\u0442\u0430.");
  }
  function extract(selectors) {
    const assessment = isAssessment(location.href);
    let root;
    let adapter = "generic";
    let submitSelector = "";
    let carouselSelector = "";
    if (selectors.root) {
      root = unique(document, selectors.root);
    } else {
      const activities = assessment ? [] : all(document, "div.activity.relative .swiper-slide-active").filter(
        (element) => element.querySelector("form.activity input") && !element.querySelector("label.answerTrue")
      );
      if (activities.length) {
        root = activities[0];
        adapter = "beyim-activity";
        const submit = root.querySelector("form.activity button[type=submit]");
        if (!submit) throw new SolverError("\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430 \u043A\u043D\u043E\u043F\u043A\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u0443\u043F\u0440\u0430\u0436\u043D\u0435\u043D\u0438\u044F Beyim.");
        submitSelector = path(submit);
        const carousel = root.closest("div.activity.relative");
        carouselSelector = carousel ? path(carousel) : "";
      } else {
        root = genericRoot(assessment);
      }
    }
    const inputs = selectors.options ? all(root, selectors.options) : [...root.querySelectorAll(CONTROL)].filter(usable);
    if (inputs.length > 30) throw new SolverError("\u041D\u0430\u0439\u0434\u0435\u043D\u043E \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u043D\u043E\u0433\u043E \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u043E\u0432. \u0423\u0442\u043E\u0447\u043D\u0438\u0442\u0435 \u0431\u043B\u043E\u043A \u0437\u0430\u0434\u0430\u043D\u0438\u044F.");
    const options = inputs.map((element) => {
      const native = element.matches(CONTROL) ? element : element.querySelector(CONTROL);
      const label = native ? labelsOf(native).find(visible) : null;
      return {
        text: native ? labelFor(native) || text2(element) : text2(element),
        selector: path(element),
        label_selector: label ? path(label) : "",
        kind: native?.getAttribute("type") || native?.getAttribute("role") || "custom",
        group: native?.getAttribute("name") || "",
        disabled: native?.disabled || element.getAttribute("aria-disabled") === "true"
      };
    });
    if (options.some((option) => !option.text)) {
      throw new SolverError("\u0423 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u043E\u0432 \u043D\u0435\u0442 \u0447\u0438\u0442\u0430\u0435\u043C\u043E\u0433\u043E \u0442\u0435\u043A\u0441\u0442\u0430. \u041D\u0443\u0436\u043D\u0430 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 \u0441\u0435\u043B\u0435\u043A\u0442\u043E\u0440\u0430 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u043E\u0432.");
    }
    if (options.some((option) => option.disabled)) {
      throw new SolverError("\u0412\u0430\u0440\u0438\u0430\u043D\u0442\u044B \u043E\u0442\u0432\u0435\u0442\u0430 \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D\u044B. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043D\u0435\u043E\u0442\u0432\u0435\u0447\u0435\u043D\u043D\u043E\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u0435.");
    }
    const kinds = new Set(options.map((option) => option.kind));
    if (kinds.size > 1) throw new SolverError("\u0412 \u0431\u043B\u043E\u043A\u0435 \u0441\u043C\u0435\u0448\u0430\u043D\u044B \u0440\u0430\u0437\u043D\u044B\u0435 \u0442\u0438\u043F\u044B \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u043E\u0432. \u041D\u0443\u0436\u0435\u043D \u0431\u043E\u043B\u0435\u0435 \u0442\u043E\u0447\u043D\u044B\u0439 \u0441\u0435\u043B\u0435\u043A\u0442\u043E\u0440.");
    const groups = new Set(options.map((option) => option.group).filter(Boolean));
    if (groups.size > 1) throw new SolverError("\u0412 \u0431\u043B\u043E\u043A\u0435 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0432\u043E\u043F\u0440\u043E\u0441\u043E\u0432. \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043E\u0434\u0438\u043D \u0432\u043E\u043F\u0440\u043E\u0441.");
    let prompt;
    if (selectors.question) {
      prompt = text2(unique(root, selectors.question));
    } else if (adapter === "beyim-activity") {
      const form = root.querySelector("form.activity");
      const questionBlock = form?.previousElementSibling;
      if (!questionBlock) throw new SolverError("\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D \u0442\u0435\u043A\u0441\u0442 \u0443\u043F\u0440\u0430\u0436\u043D\u0435\u043D\u0438\u044F Beyim.");
      prompt = text2(questionBlock);
    } else {
      prompt = genericPrompt(root);
    }
    if (!prompt || prompt.length > 16e3) throw new SolverError("\u0422\u0435\u043A\u0441\u0442 \u0432\u043E\u043F\u0440\u043E\u0441\u0430 \u043F\u0443\u0441\u0442\u043E\u0439 \u0438\u043B\u0438 \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0434\u043B\u0438\u043D\u043D\u044B\u0439.");
    let kind = kinds.has("checkbox") ? "multiple" : "single";
    let inputSelector = "";
    const inferredFields = assessment && !options.length ? all(root, TEXT_CONTROL) : [];
    if (selectors.input || inferredFields.length === 1) {
      if (options.length) throw new SolverError("\u0412 \u0431\u043B\u043E\u043A\u0435 \u043E\u0434\u043D\u043E\u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E \u0442\u0435\u043A\u0441\u0442\u043E\u0432\u043E\u0435 \u043F\u043E\u043B\u0435 \u0438 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u044B. \u0423\u0442\u043E\u0447\u043D\u0438\u0442\u0435 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438.");
      const field = selectors.input ? unique(root, selectors.input) : inferredFields[0];
      if (!field.matches(TEXT_CONTROL)) {
        throw new SolverError("\u0421\u0435\u043B\u0435\u043A\u0442\u043E\u0440 \u0442\u0435\u043A\u0441\u0442\u043E\u0432\u043E\u0433\u043E \u043E\u0442\u0432\u0435\u0442\u0430 \u0434\u043E\u043B\u0436\u0435\u043D \u0443\u043A\u0430\u0437\u044B\u0432\u0430\u0442\u044C \u043D\u0430 \u0442\u0435\u043A\u0441\u0442\u043E\u0432\u043E\u0435/\u0447\u0438\u0441\u043B\u043E\u0432\u043E\u0435 \u043F\u043E\u043B\u0435.");
      }
      if (field.disabled || field.readOnly) {
        throw new SolverError("\u041F\u043E\u043B\u0435 \u043E\u0442\u0432\u0435\u0442\u0430 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E.");
      }
      kind = "text";
      inputSelector = path(field);
    } else if (options.length < 2) {
      throw new SolverError("\u041D\u0443\u0436\u043D\u043E \u0445\u043E\u0442\u044F \u0431\u044B \u0434\u0432\u0430 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u0430 \u0438\u043B\u0438 \u043D\u0430\u0441\u0442\u0440\u043E\u0435\u043D\u043D\u043E\u0435 \u043F\u043E\u043B\u0435 \u0442\u0435\u043A\u0441\u0442\u043E\u0432\u043E\u0433\u043E \u043E\u0442\u0432\u0435\u0442\u0430.");
    }
    const hasImage = all(root, "img,canvas,svg").some((element) => {
      const rect = element.getBoundingClientRect();
      return rect.width >= 80 && rect.height >= 60;
    });
    return {
      text: prompt,
      options,
      kind,
      root: path(root),
      input_selector: inputSelector,
      has_image: hasImage,
      adapter,
      submit_selector: submitSelector,
      carousel_selector: carouselSelector,
      revision: revision(root)
    };
  }
  function findButton(selector, pattern) {
    if (selector) {
      const found = all(document, selector);
      if (found.length > 1) throw new SolverError("\u041D\u0430\u0439\u0434\u0435\u043D\u043E \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043E\u0434\u0438\u043D\u0430\u043A\u043E\u0432\u044B\u0445 \u043A\u043D\u043E\u043F\u043E\u043A. \u0423\u0442\u043E\u0447\u043D\u0438\u0442\u0435 CSS-\u0441\u0435\u043B\u0435\u043A\u0442\u043E\u0440.");
      return found[0] ?? null;
    }
    const buttons = all(document, "button,[role=button]").filter((element) => pattern.test(text2(element).trim()));
    if (buttons.length > 1) throw new SolverError("\u041D\u0430\u0439\u0434\u0435\u043D\u043E \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043E\u0434\u0438\u043D\u0430\u043A\u043E\u0432\u044B\u0445 \u043A\u043D\u043E\u043F\u043E\u043A. \u0423\u0442\u043E\u0447\u043D\u0438\u0442\u0435 CSS-\u0441\u0435\u043B\u0435\u043A\u0442\u043E\u0440.");
    return buttons[0] ?? null;
  }
  function isComplete(selectors) {
    if (selectors.complete) {
      const found = all(document, selectors.complete);
      if (found.length > 1) throw new SolverError("\u0421\u0435\u043B\u0435\u043A\u0442\u043E\u0440 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u044F \u0443\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442 \u043D\u0430 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432.");
      return found.length === 1;
    }
    const forms = all(document, "div.activity.relative").flatMap((carousel) => [...carousel.querySelectorAll("form.activity")]);
    if (!selectors.root && forms.length) {
      return forms.every((form) => !!form.querySelector("label.answerTrue"));
    }
    return document.body.innerText.split("\n").some((line) => COMPLETE.test(line.trim()));
  }
  function wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  async function prepare(check = () => {
  }) {
    const settings = await loadSettings(location.href);
    if (settings.selectors.root) return;
    const carousels = all(document, "div.activity.relative");
    for (const carousel of carousels) {
      const slides = [...carousel.querySelectorAll(".swiper-slide")];
      const pending = slides.map((slide, index) => ({ slide, index })).filter(({ slide }) => slide.querySelector("form.activity input") && !slide.querySelector("label.answerTrue"));
      if (!pending.length) continue;
      const desired = pending[0].index;
      for (let attempt = 0; attempt <= slides.length; attempt += 1) {
        const current = slides.findIndex((slide) => slide.classList.contains("swiper-slide-active"));
        if (current === desired) {
          slides[desired].scrollIntoView({ block: "nearest" });
          return;
        }
        if (current < 0) throw new SolverError("\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0435 \u0443\u043F\u0440\u0430\u0436\u043D\u0435\u043D\u0438\u0435 \u043A\u0430\u0440\u0443\u0441\u0435\u043B\u0438.");
        const direction = current < desired ? ".swiper-button-next" : ".swiper-button-prev";
        const arrow = carousel.querySelector(direction);
        if (!arrow || arrow.classList.contains("swiper-button-disabled")) {
          throw new SolverError("\u0421\u0442\u0440\u0435\u043B\u043A\u0430 \u043A\u0430\u0440\u0443\u0441\u0435\u043B\u0438 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430.");
        }
        check();
        arrow.click();
        const deadline = performance.now() + settings.transition_timeout * 1e3;
        let moved = false;
        while (performance.now() < deadline) {
          const next = slides.findIndex((slide) => slide.classList.contains("swiper-slide-active"));
          if (next !== current) {
            moved = true;
            break;
          }
          await wait(100);
        }
        if (!moved) throw new SolverError("\u041A\u0430\u0440\u0443\u0441\u0435\u043B\u044C \u043D\u0435 \u043F\u0435\u0440\u0435\u043A\u043B\u044E\u0447\u0438\u043B\u0430\u0441\u044C.");
        await wait(350);
      }
      throw new SolverError("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u0443\u043F\u0440\u0430\u0436\u043D\u0435\u043D\u0438\u0435 \u043A\u0430\u0440\u0443\u0441\u0435\u043B\u0438.");
    }
  }
  async function apply(question, answer, settings) {
    settings ??= await loadSettings(location.href);
    const current = extract(settings.selectors);
    if (!sameQuestion(question, current)) {
      throw new SolverError("\u0417\u0430\u0434\u0430\u043D\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u043E\u0441\u044C \u0432\u043E \u0432\u0440\u0435\u043C\u044F \u0440\u0435\u0448\u0435\u043D\u0438\u044F. \u0421\u0442\u0430\u0440\u044B\u0439 \u043E\u0442\u0432\u0435\u0442 \u043D\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D.");
    }
    if (question.kind === "text") {
      const field = document.querySelector(question.input_selector);
      if (!field) throw new SolverError("\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E \u043F\u043E\u043B\u0435 \u0442\u0435\u043A\u0441\u0442\u043E\u0432\u043E\u0433\u043E \u043E\u0442\u0432\u0435\u0442\u0430.");
      field.focus();
      field.value = answer.text_answer;
      field.dispatchEvent(new Event("input", { bubbles: true }));
      field.dispatchEvent(new Event("change", { bubbles: true }));
      return;
    }
    const selected = new Set(answer.answer_ids);
    question.options.forEach((option, index) => {
      const id = index + 1;
      const target = document.querySelector(option.selector);
      if (!target) throw new SolverError("\u0412\u0430\u0440\u0438\u0430\u043D\u0442 \u043E\u0442\u0432\u0435\u0442\u0430 \u0438\u0441\u0447\u0435\u0437 \u0441\u043E \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B.");
      const native = target.matches(CONTROL) ? target : target.querySelector(CONTROL);
      if (native instanceof HTMLInputElement) {
        const desired = selected.has(id);
        if (native.checked !== desired) {
          const label = option.label_selector ? document.querySelector(option.label_selector) : null;
          if (label && !visible(native)) label.click();
          else native.click();
        }
        if (native.checked !== desired) throw new SolverError("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C \u0432\u044B\u0431\u043E\u0440 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u0430.");
      } else {
        const control = native ?? target;
        const checked = () => control.getAttribute("aria-checked") === "true" || control.getAttribute("aria-selected") === "true" || control.getAttribute("aria-pressed") === "true" || control.getAttribute("data-state") === "checked";
        const desired = selected.has(id);
        if (checked() !== desired && (question.kind === "multiple" || desired)) control.click();
        if (desired && !checked()) throw new SolverError("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u0432\u044B\u0431\u043E\u0440 \u043D\u0435\u0441\u0442\u0430\u043D\u0434\u0430\u0440\u0442\u043D\u043E\u0433\u043E \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u0430.");
        if (question.kind === "multiple" && checked() !== desired) throw new SolverError("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043D\u044F\u0442\u044C \u043B\u0438\u0448\u043D\u0438\u0439 \u0432\u0430\u0440\u0438\u0430\u043D\u0442.");
      }
    });
  }
  async function betaSubmit(question, answer, check, selectOnly = false) {
    const settings = await loadSettings(location.href);
    const current = extract(settings.selectors);
    const root = document.querySelector(question.root);
    if (!root || current.revision !== question.revision || !sameQuestion(question, current)) {
      throw new SolverError("\u0417\u0430\u0434\u0430\u043D\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u043E\u0441\u044C. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u0420\u0430\u0437\u043E\u0431\u0440\u0430\u0442\u044C \u0437\u0430\u0434\u0430\u043D\u0438\u0435\xBB \u0435\u0449\u0451 \u0440\u0430\u0437.");
    }
    if (selectOnly) {
      check();
      await apply(question, answer, settings);
      return;
    }
    if (isAssessment(location.href)) throw new SolverError("\u0412 \u0442\u0435\u0441\u0442\u0435 \u043C\u043E\u0436\u043D\u043E \u0432\u044B\u0431\u0440\u0430\u0442\u044C \u043E\u0442\u0432\u0435\u0442. \u041F\u0435\u0440\u0435\u0445\u043E\u0434 \u0438 \u0441\u0434\u0430\u0447\u0430 \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u044E\u0442\u0441\u044F \u043D\u0430 Beyim.");
    const button = question.adapter === "beyim-activity" ? root.querySelector("form.activity button[type=submit]") : findButton(settings.selectors.submit, SUBMIT);
    if (!button) throw new SolverError("\u041A\u043D\u043E\u043F\u043A\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u0435 \u0432\u0440\u0443\u0447\u043D\u0443\u044E.");
    const identity = JSON.stringify([question.revision, question.text, question.options.map((option) => option.text)]);
    const attempts = submitted.get(root) ?? /* @__PURE__ */ new Set();
    if (attempts.has(identity)) throw new SolverError("\u041E\u0442\u0432\u0435\u0442 \u0443\u0436\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435.");
    check();
    await apply(question, answer, settings);
    check();
    const selectedQuestion = extract(settings.selectors);
    if (selectedQuestion.revision !== question.revision || !sameQuestion(question, selectedQuestion)) {
      throw new SolverError("\u0417\u0430\u0434\u0430\u043D\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u043E\u0441\u044C. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u0420\u0430\u0437\u043E\u0431\u0440\u0430\u0442\u044C \u0437\u0430\u0434\u0430\u043D\u0438\u0435\xBB \u0435\u0449\u0451 \u0440\u0430\u0437.");
    }
    if (!button.isConnected || button.disabled) {
      throw new SolverError("\u041A\u043D\u043E\u043F\u043A\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0439 \u043E\u0442\u0432\u0435\u0442 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435.");
    }
    attempts.add(identity);
    submitted.set(root, attempts);
    button.click();
    if (question.adapter !== "beyim-activity") return;
    const deadline = performance.now() + settings.transition_timeout * 1e3;
    while (performance.now() < deadline) {
      check();
      if (root.querySelector("form.activity label.answerTrue")) return;
      await wait(150);
    }
    throw new SolverError("Beyim \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u043B \u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u044B\u0439 \u043E\u0442\u0432\u0435\u0442. \u041F\u043E\u0441\u043C\u043E\u0442\u0440\u0438\u0442\u0435 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435.");
  }
  async function betaOperation(operation, work) {
    const controller = new AbortController();
    cancelled.set(operation, controller);
    try {
      await work(() => {
        if (controller.signal.aborted) throw new Cancelled("\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E.");
      });
    } finally {
      cancelled.delete(operation);
    }
  }
  async function waitForChange(question, settings) {
    const deadline = performance.now() + settings.transition_timeout * 1e3;
    let nextClicked = false;
    while (performance.now() < deadline) {
      if (isComplete(settings.selectors)) return { state: "complete" };
      try {
        const current = extract(settings.selectors);
        if (!sameQuestion(question, current)) return { state: "question", question: current };
      } catch {
      }
      if (!nextClicked) {
        const next = findButton(settings.selectors.next, NEXT);
        if (next && !next.disabled) {
          next.click();
          nextClicked = true;
        }
      }
      await wait(150);
    }
    throw new SolverError("\u041D\u043E\u0432\u043E\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u0435 \u043D\u0435 \u043F\u043E\u044F\u0432\u0438\u043B\u043E\u0441\u044C. \u041F\u043E\u0432\u0442\u043E\u0440\u043D\u0430\u044F \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u0437\u0430\u043F\u0440\u0435\u0449\u0435\u043D\u0430; \u043F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443.");
  }
  async function advance(question) {
    if (isAssessment(location.href)) throw new SolverError("\u0421\u0434\u0430\u0439\u0442\u0435 \u0442\u0435\u0441\u0442 \u0432\u0440\u0443\u0447\u043D\u0443\u044E \u043D\u0430 Beyim.");
    const settings = await loadSettings(location.href);
    if (question.adapter === "beyim-activity") {
      const button = document.querySelector(question.submit_selector);
      if (!button) throw new SolverError("\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430 \u043A\u043D\u043E\u043F\u043A\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u0443\u043F\u0440\u0430\u0436\u043D\u0435\u043D\u0438\u044F Beyim.");
      if (button.disabled) {
        throw new SolverError("\u041A\u043D\u043E\u043F\u043A\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u0443\u043F\u0440\u0430\u0436\u043D\u0435\u043D\u0438\u044F \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430. \u041E\u0442\u0432\u0435\u0442 \u043D\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D.");
      }
      button.click();
      return waitForChange(question, settings);
    }
    const submit = findButton(settings.selectors.submit, SUBMIT);
    const next = findButton(settings.selectors.next, NEXT);
    if (submit && !submit.disabled) submit.click();
    else if (next && !next.disabled) next.click();
    else throw new SolverError("\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E\u0439 \u043A\u043D\u043E\u043F\u043A\u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438/\u043F\u0435\u0440\u0435\u0445\u043E\u0434\u0430. \u041E\u0442\u0432\u0435\u0442 \u0432\u044B\u0431\u0440\u0430\u043D, \u043D\u043E \u043D\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D.");
    return waitForChange(question, settings);
  }
  function waitForImage(image) {
    if (image.complete && image.naturalWidth > 0) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        cleanup();
        reject(new SolverError("\u0418\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u0435\u0449\u0451 \u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u043B\u043E\u0441\u044C."));
      }, 1e4);
      const done = () => {
        cleanup();
        if (image.naturalWidth > 0) resolve();
        else reject(new SolverError("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u044F."));
      };
      const cleanup = () => {
        clearTimeout(timer);
        image.removeEventListener("load", done);
        image.removeEventListener("error", done);
      };
      image.addEventListener("load", done, { once: true });
      image.addEventListener("error", done, { once: true });
    });
  }
  async function sourceOf(element, max) {
    if (element instanceof HTMLImageElement) {
      await waitForImage(element);
      return { source: element, width: element.naturalWidth, height: element.naturalHeight };
    }
    if (element instanceof HTMLCanvasElement) {
      return { source: element, width: element.width, height: element.height };
    }
    if (element instanceof SVGSVGElement) {
      const markup = new XMLSerializer().serializeToString(element);
      const url = URL.createObjectURL(new Blob([markup], { type: "image/svg+xml" }));
      try {
        const image = new Image();
        image.src = url;
        await image.decode();
        return { source: image, width: image.naturalWidth, height: image.naturalHeight };
      } finally {
        URL.revokeObjectURL(url);
      }
    }
    throw new SolverError("\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D \u0440\u0438\u0441\u0443\u043D\u043E\u043A \u0437\u0430\u0434\u0430\u043D\u0438\u044F.");
  }
  function draw(source, width, height, max) {
    const ratio = Math.min(1, max / Math.max(width, height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(width * ratio));
    canvas.height = Math.max(1, Math.round(height * ratio));
    const context = canvas.getContext("2d");
    if (!context) throw new SolverError("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u0438\u0442\u044C \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435.");
    context.fillStyle = "white";
    context.fillRect(0, 0, canvas.width, canvas.height);
    try {
      context.drawImage(source, 0, 0, canvas.width, canvas.height);
      return { dataUrl: canvas.toDataURL("image/jpeg", 0.9), width: canvas.width, height: canvas.height };
    } catch (error) {
      console.error("Beyim Solver image draw", error);
      throw new SolverError("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u0440\u043E\u0447\u0438\u0442\u0430\u0442\u044C \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u044F. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0432\u044B\u0434\u0435\u043B\u0438\u0442\u044C \u0431\u043B\u043E\u043A \u0447\u0435\u0440\u0435\u0437 \u0441\u0435\u043B\u0435\u043A\u0442\u043E\u0440.");
    }
  }
  function drawRegion(source, sx, sy, sw, sh, max) {
    const ratio = Math.min(1, max / Math.max(sw, sh));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(sw * ratio));
    canvas.height = Math.max(1, Math.round(sh * ratio));
    const context = canvas.getContext("2d");
    if (!context) throw new SolverError("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u0438\u0442\u044C \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435.");
    context.fillStyle = "white";
    context.fillRect(0, 0, canvas.width, canvas.height);
    try {
      context.drawImage(source, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);
      return { dataUrl: canvas.toDataURL("image/jpeg", 0.9), width: canvas.width, height: canvas.height };
    } catch (error) {
      console.error("Beyim Solver image crop", error);
      throw new SolverError("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0431\u0440\u0435\u0437\u0430\u0442\u044C \u0441\u043D\u0438\u043C\u043E\u043A \u0437\u0430\u0434\u0430\u043D\u0438\u044F.");
    }
  }
  async function screenshot(element, max) {
    element.scrollIntoView({ block: "center", inline: "center" });
    await wait(350);
    const rect = element.getBoundingClientRect();
    const viewport = { width: window.innerWidth, height: window.innerHeight };
    if (rect.width < 1 || rect.height < 1) throw new SolverError("\u0420\u0438\u0441\u0443\u043D\u043E\u043A \u0438\u043C\u0435\u0435\u0442 \u043D\u0443\u043B\u0435\u0432\u043E\u0439 \u0440\u0430\u0437\u043C\u0435\u0440.");
    if (rect.left < 0 || rect.top < 0 || rect.right > viewport.width || rect.bottom > viewport.height) {
      throw new SolverError("\u0420\u0438\u0441\u0443\u043D\u043E\u043A \u043D\u0435 \u043F\u043E\u043C\u0435\u0449\u0430\u0435\u0442\u0441\u044F \u0432 \u043E\u043A\u043D\u043E. \u0423\u043C\u0435\u043D\u044C\u0448\u0438\u0442\u0435 \u043C\u0430\u0441\u0448\u0442\u0430\u0431 Beyim \u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u0440\u0430\u0437\u0431\u043E\u0440.");
    }
    const response = await import_webextension_polyfill2.default.runtime.sendMessage({ type: "capture" });
    if (!response?.ok) {
      throw new SolverError(response?.error || "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u0434\u0435\u043B\u0430\u0442\u044C \u0441\u043D\u0438\u043C\u043E\u043A \u0437\u0430\u0434\u0430\u043D\u0438\u044F.");
    }
    const after = element.getBoundingClientRect();
    const bounds = ["left", "top", "width", "height"];
    if (!element.isConnected || bounds.some((key) => Math.abs(after[key] - rect[key]) > 1)) {
      throw new SolverError("\u0420\u0438\u0441\u0443\u043D\u043E\u043A \u0441\u043C\u0435\u0441\u0442\u0438\u043B\u0441\u044F. \u041E\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u0435 \u043F\u0440\u043E\u043A\u0440\u0443\u0442\u043A\u0443 \u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u0440\u0430\u0437\u0431\u043E\u0440.");
    }
    const image = new Image();
    image.src = response.dataUrl;
    await image.decode();
    const scaleX = image.naturalWidth / viewport.width;
    const scaleY = image.naturalHeight / viewport.height;
    const sx = Math.max(0, Math.min(image.naturalWidth - 1, rect.left * scaleX));
    const sy = Math.max(0, Math.min(image.naturalHeight - 1, rect.top * scaleY));
    const sw = Math.min(image.naturalWidth - sx, rect.width * scaleX);
    const sh = Math.min(image.naturalHeight - sy, rect.height * scaleY);
    if (sw < 1 || sh < 1) throw new SolverError("\u0420\u0438\u0441\u0443\u043D\u043E\u043A \u043D\u0430\u0445\u043E\u0434\u0438\u0442\u0441\u044F \u0432\u043D\u0435 \u0432\u0438\u0434\u0438\u043C\u043E\u0439 \u043E\u0431\u043B\u0430\u0441\u0442\u0438.");
    return drawRegion(image, sx, sy, sw, sh, max);
  }
  async function captureImage(question, max) {
    const root = document.querySelector(question.root);
    if (!root) throw new SolverError("\u0411\u043B\u043E\u043A \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u0438\u0441\u0447\u0435\u0437 \u0441\u043E \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B.");
    if (question.revision && question.revision !== revision(root)) {
      throw new SolverError("\u0417\u0430\u0434\u0430\u043D\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u043E\u0441\u044C. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u0420\u0430\u0437\u043E\u0431\u0440\u0430\u0442\u044C \u0437\u0430\u0434\u0430\u043D\u0438\u0435\xBB \u0435\u0449\u0451 \u0440\u0430\u0437.");
    }
    const images = all(root, "img,canvas,svg").filter((element) => {
      const rect = element.getBoundingClientRect();
      return rect.width >= 80 && rect.height >= 60;
    }).sort((left, right) => {
      const a = left.getBoundingClientRect();
      const b = right.getBoundingClientRect();
      return b.width * b.height - a.width * a.height;
    });
    if (!images.length) throw new SolverError("\u0412 \u0437\u0430\u0434\u0430\u043D\u0438\u0438 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D \u0440\u0438\u0441\u0443\u043D\u043E\u043A.");
    const limit = Math.min(2e3, Math.max(256, max));
    try {
      const { source, width, height } = await sourceOf(images[0], limit);
      return draw(source, width, height, limit);
    } catch (error) {
      console.warn("Beyim Solver image fallback", error);
      try {
        return await screenshot(images[0], limit);
      } catch (fallbackError) {
        console.error("Beyim Solver screenshot fallback", fallbackError);
        const detail = fallbackError instanceof Error ? fallbackError.message : String(fallbackError);
        throw new SolverError(`\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u0440\u043E\u0447\u0438\u0442\u0430\u0442\u044C \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u044F. ${detail}`);
      }
    }
  }
  async function handle(request) {
    switch (request.type) {
      case "extract": {
        const settings = await loadSettings(location.href);
        return extract(settings.selectors);
      }
      case "apply":
        await apply(request.question, request.answer);
        return true;
      case "advance":
        return advance(request.question);
      case "prepare":
        await prepare();
        return true;
      case "beta-prepare":
        return betaOperation(request.operation, prepare);
      case "beta-submit":
        return betaOperation(request.operation, (check) => betaSubmit(request.question, request.answer, check));
      case "beta-select":
        return betaOperation(request.operation, (check) => betaSubmit(request.question, request.answer, check, true));
      case "beta-cancel":
        cancelled.get(request.operation)?.abort();
        return true;
      case "complete": {
        const settings = await loadSettings(location.href);
        return isComplete(settings.selectors);
      }
      case "image":
        return captureImage(request.question, request.max);
    }
  }
  import_webextension_polyfill2.default.runtime.onMessage.addListener((message) => {
    const incoming = message;
    if (!incoming || incoming.type !== "content") return void 0;
    return handle(incoming.request).then((data) => ({ ok: true, data })).catch((error) => {
      const cancelled2 = error instanceof Cancelled;
      return { ok: false, error: error instanceof Error ? error.message : String(error), cancelled: cancelled2 };
    });
  });
})();
